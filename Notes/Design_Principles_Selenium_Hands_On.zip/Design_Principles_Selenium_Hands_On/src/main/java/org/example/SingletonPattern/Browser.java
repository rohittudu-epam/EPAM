package org.example.SingletonPattern;

public class Browser {
//    1. Private static instance of the class
    private volatile static Browser browser;

//    2. Private constructor to prevent/avoid instantiation/object
    private Browser() throws IllegalAccessException {
        if (browser != null) {
            throw new IllegalAccessException("Browser Already Running");
        }
    }

// 3. Public static getInstance
//    public synchronized static Browser getInstance(){
//        if (browser == null){
//            return new Browser();
//        }
//
//        return browser;
//    }

//    No violation of Singleton class -> Proper thread management using Synchronized
//    double check method
    public static Browser getInstance() throws IllegalAccessException {
        if (browser == null){
            synchronized (Browser.class){
                if (browser == null){
                    browser = new Browser();
                }
            }
        }

        return browser;
    }

    public void displayMessage(){
        System.out.println("Browser is Running....");
    }

}
