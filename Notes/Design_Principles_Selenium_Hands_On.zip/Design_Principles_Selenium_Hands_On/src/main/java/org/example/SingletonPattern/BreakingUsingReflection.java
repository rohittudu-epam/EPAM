package org.example.SingletonPattern;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;

public class BreakingUsingReflection {
    public static void main(String[] args) throws IllegalAccessException {
        Browser browserOne = Browser.getInstance();
        Browser browserTwo = null;

        try {
            Constructor<Browser> constructor = Browser.class.getDeclaredConstructor();
            constructor.setAccessible(true);
            browserTwo = constructor.newInstance();

            System.out.println("HashCode of BrowserOne: " + browserOne.hashCode());
            System.out.println("HashCode of BrowserTwo: " + browserTwo.hashCode());

        } catch (NoSuchMethodException e) {
            System.out.println("Unable to find the constructor");
        } catch (InvocationTargetException | InstantiationException | IllegalAccessException e) {
            System.out.println(Arrays.toString(e.getStackTrace()));
        }
    }
}
