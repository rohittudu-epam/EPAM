package org.example.SingletonPattern;

import java.io.Serializable;

public class SerializedBrowser implements Serializable {
    private volatile static SerializedBrowser browser;

    private SerializedBrowser(){
        if (browser != null){
            throw new IllegalStateException("Object already exits");
        }
    }

    public static SerializedBrowser getInstance(){
        if (browser == null){
            synchronized (SerializedBrowser.class){
                if (browser == null){
                    return new SerializedBrowser();
                }

            }
        }

        return browser;
    }

    protected Object readResolve(){
        return getInstance();
    }

}
