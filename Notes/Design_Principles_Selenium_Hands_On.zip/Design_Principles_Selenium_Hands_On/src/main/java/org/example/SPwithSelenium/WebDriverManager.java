package org.example.SPwithSelenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebDriverManager {
    private static volatile WebDriverManager instance;
    private static ThreadLocal<WebDriver> tDriver = new ThreadLocal<>();

    private WebDriverManager(){}

    private void initDriver(String browser){
        switch(browser){
            case "chrome":
                tDriver.set(new ChromeDriver());
                break;
            case "firefox":
                tDriver.set(new FirefoxDriver());
                break;
            case "edge":
                tDriver.set(new EdgeDriver());
                break;
        }
    }

    public static WebDriverManager getInstance(String browser){
        if (instance == null){
            synchronized (WebDriverManager.class){
                if (instance == null){
                    instance = new WebDriverManager();
                }
            }
        }

        if (tDriver.get() == null){
            instance.initDriver(browser);
        }

        return instance;
    }

    public WebDriver getDriver(){
        return tDriver.get();
    }

    public static void quitBrowser(){
        if (tDriver.get() != null){
            tDriver.get().quit();
            tDriver.remove();
        }
    }
}
