package org.example.SingletonPattern;

import java.io.*;

public class BrowserReadResolve {
    public static void main(String[] args){
        try {
            Browser instance1 = Browser.getInstance();

            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("browser.json"));
            out.writeObject(instance1);
            out.close();

            ObjectInputStream in = new ObjectInputStream(new FileInputStream("browser.json"));
            Browser instance2 = (Browser) in.readObject();
            in.close();

            System.out.println("Instance1 HashCode: " + instance1.hashCode());
            System.out.println("Instance2 HashCode: " + instance2.hashCode());


        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
